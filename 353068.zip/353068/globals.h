#include "macros.h"

#define DEBUG_PRINT false
#define ENABLE_WARNINGS true

#define VWSL_NUM 104857600
//#define VWSL_NUM 10050000

#define LOCKED true
#define UNLOCKED false

#define COMMIT true
#define ABORT false

#define COLOR_RED "\x1b[31m"
#define COLOR_GREEN "\x1b[32m"
#define COLOR_CYAN "\x1b[36m"
#define COLOR_RESET "\x1b[0m"

// python3 submit.py --uuid VcEicfD4QjwjBasjGdnDLWszIXK4U4OF 353068.zip